import ResumeEditor from "@/components/resume-editor"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50">
      <ResumeEditor />
    </main>
  )
}
