"use client"

import { useState } from "react"
import { DndProvider } from "react-dnd"
import { HTML5Backend } from "react-dnd-html5-backend"
import { ResumeSection } from "@/components/resume-section"
import { PDFPreview } from "@/components/pdf-preview"
import { Button } from "@/components/ui/button"
import { PlusCircle, Save, FileDown } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { ResizablePanels } from "@/components/resizable-panels"

// Define the types for our hierarchical structure
export interface BulletPoint {
  id: string
  text: string
  status: boolean
}

export interface ResumeItem {
  id: string
  title: string
  organization: string
  startDate: string
  endDate: string
  location: string
  status: boolean
  isCollapsed: boolean
  bulletPoints: BulletPoint[]
}

export interface Section {
  id: string
  title: string
  status: boolean
  isCollapsed: boolean
  items: ResumeItem[]
}

export default function ResumeEditor() {
  // Mock data - this would come from your API
  const [sections, setSections] = useState<Section[]>([
    {
      id: "1",
      title: "Experience",
      status: true,
      isCollapsed: false,
      items: [
        {
          id: "101",
          title:
            '<strong>Software Engineer</strong> - <a href="https://techcompany.com" target="_blank" rel="noopener noreferrer">Tech Company</a>',
          organization: "Tech Company",
          startDate: "Jan 2020",
          endDate: "Present",
          location: "San Francisco, CA",
          status: true,
          isCollapsed: false,
          bulletPoints: [
            {
              id: "1001",
              text: "Developed and maintained web applications using <strong>React</strong> and <strong>Node.js</strong>",
              status: true,
            },
            {
              id: "1002",
              text: "Improved application performance by <strong>40%</strong> through code optimization and <em>advanced caching strategies</em>",
              status: true,
            },
            {
              id: "1003",
              text: 'Collaborated with cross-functional teams to deliver features on time, check out our <a href="https://example.com" target="_blank" rel="noopener noreferrer">project showcase</a>',
              status: true,
            },
          ],
        },
        {
          id: "102",
          title: "<em>Junior Developer</em>",
          organization: "Startup Inc",
          startDate: "Jun 2018",
          endDate: "Dec 2019",
          location: "Austin, TX",
          status: true,
          isCollapsed: false,
          bulletPoints: [
            {
              id: "1004",
              text: "Built responsive user interfaces using <strong>HTML</strong>, <strong>CSS</strong>, and <strong>JavaScript</strong>",
              status: true,
            },
            {
              id: "1005",
              text: "Participated in code reviews and implemented feedback with <u>100% completion rate</u>",
              status: true,
            },
          ],
        },
      ],
    },
    {
      id: "2",
      title: "Education",
      status: true,
      isCollapsed: false,
      items: [
        {
          id: "201",
          title: "<strong>Bachelor of Science</strong> in Computer Science",
          organization: "University of Technology",
          startDate: "Sep 2014",
          endDate: "May 2018",
          location: "Boston, MA",
          status: true,
          isCollapsed: false,
          bulletPoints: [
            { id: "2001", text: "GPA: 3.8/4.0", status: true },
            { id: "2002", text: "Relevant coursework: Data Structures, Algorithms, Web Development", status: true },
          ],
        },
      ],
    },
    {
      id: "3",
      title: "Skills",
      status: true,
      isCollapsed: false,
      items: [
        {
          id: "301",
          title: "Programming Languages",
          organization: "",
          startDate: "",
          endDate: "",
          location: "",
          status: true,
          isCollapsed: false,
          bulletPoints: [{ id: "3001", text: "JavaScript, TypeScript, Python, Java", status: true }],
        },
        {
          id: "302",
          title: "Frameworks & Libraries",
          organization: "",
          startDate: "",
          endDate: "",
          location: "",
          status: true,
          isCollapsed: false,
          bulletPoints: [{ id: "3002", text: "React, Next.js, Node.js, Express", status: true }],
        },
      ],
    },
  ])

  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  // Function to move sections
  const moveSection = (dragIndex: number, hoverIndex: number) => {
    const draggedSection = sections[dragIndex]
    const newSections = [...sections]
    newSections.splice(dragIndex, 1)
    newSections.splice(hoverIndex, 0, draggedSection)
    setSections(newSections)
  }

  // Function to move items within a section
  const moveItem = (sectionId: string, dragIndex: number, hoverIndex: number) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          const newItems = [...section.items]
          const draggedItem = newItems[dragIndex]
          newItems.splice(dragIndex, 1)
          newItems.splice(hoverIndex, 0, draggedItem)
          return { ...section, items: newItems }
        }
        return section
      })
    })
  }

  // Function to move bullet points within an item
  const moveBulletPoint = (sectionId: string, itemId: string, dragIndex: number, hoverIndex: number) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.map((item) => {
              if (item.id === itemId) {
                const newBulletPoints = [...item.bulletPoints]
                const draggedBullet = newBulletPoints[dragIndex]
                newBulletPoints.splice(dragIndex, 1)
                newBulletPoints.splice(hoverIndex, 0, draggedBullet)
                return { ...item, bulletPoints: newBulletPoints }
              }
              return item
            }),
          }
        }
        return section
      })
    })
  }

  // Toggle section visibility
  const toggleSectionStatus = (sectionId: string) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return { ...section, status: !section.status }
        }
        return section
      })
    })
  }

  // Toggle section collapse
  const toggleSectionCollapse = (sectionId: string) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return { ...section, isCollapsed: !section.isCollapsed }
        }
        return section
      })
    })
  }

  // Toggle item visibility
  const toggleItemStatus = (sectionId: string, itemId: string) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.map((item) => {
              if (item.id === itemId) {
                return { ...item, status: !item.status }
              }
              return item
            }),
          }
        }
        return section
      })
    })
  }

  // Toggle item collapse
  const toggleItemCollapse = (sectionId: string, itemId: string) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.map((item) => {
              if (item.id === itemId) {
                return { ...item, isCollapsed: !item.isCollapsed }
              }
              return item
            }),
          }
        }
        return section
      })
    })
  }

  // Toggle bullet point visibility
  const toggleBulletStatus = (sectionId: string, itemId: string, bulletId: string) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.map((item) => {
              if (item.id === itemId) {
                return {
                  ...item,
                  bulletPoints: item.bulletPoints.map((bullet) => {
                    if (bullet.id === bulletId) {
                      return { ...bullet, status: !bullet.status }
                    }
                    return bullet
                  }),
                }
              }
              return item
            }),
          }
        }
        return section
      })
    })
  }

  // Update section title
  const updateSectionTitle = (sectionId: string, newTitle: string) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return { ...section, title: newTitle }
        }
        return section
      })
    })
  }

  // Update item details
  const updateItem = (sectionId: string, itemId: string, updatedItem: Partial<ResumeItem>) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.map((item) => {
              if (item.id === itemId) {
                return { ...item, ...updatedItem }
              }
              return item
            }),
          }
        }
        return section
      })
    })
  }

  // Update bullet point text
  const updateBulletText = (sectionId: string, itemId: string, bulletId: string, newText: string) => {
    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.map((item) => {
              if (item.id === itemId) {
                return {
                  ...item,
                  bulletPoints: item.bulletPoints.map((bullet) => {
                    if (bullet.id === bulletId) {
                      return { ...bullet, text: newText }
                    }
                    return bullet
                  }),
                }
              }
              return item
            }),
          }
        }
        return section
      })
    })
  }

  // Add a new section
  const addSection = () => {
    const newSection: Section = {
      id: `section-${Date.now()}`,
      title: "New Section",
      status: true,
      isCollapsed: false,
      items: [],
    }
    setSections([...sections, newSection])
  }

  // Add a new item to a section
  const addItem = (sectionId: string) => {
    const newItem: ResumeItem = {
      id: `item-${Date.now()}`,
      title: "New Item",
      organization: "Organization",
      startDate: "",
      endDate: "",
      location: "",
      status: true,
      isCollapsed: false,
      bulletPoints: [],
    }

    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: [...section.items, newItem],
          }
        }
        return section
      })
    })
  }

  // Add a new bullet point to an item
  const addBulletPoint = (sectionId: string, itemId: string) => {
    const newBullet: BulletPoint = {
      id: `bullet-${Date.now()}`,
      text: "New bullet point",
      status: true,
    }

    setSections((prevSections) => {
      return prevSections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.map((item) => {
              if (item.id === itemId) {
                return {
                  ...item,
                  bulletPoints: [...item.bulletPoints, newBullet],
                }
              }
              return item
            }),
          }
        }
        return section
      })
    })
  }

  // Save resume data
  const saveResume = async () => {
    setLoading(true)
    try {
      // Mock API call - replace with your actual API
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Resume saved",
        description: "Your resume has been saved successfully.",
      })
    } catch (error) {
      toast({
        title: "Error saving resume",
        description: "There was a problem saving your resume. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Download PDF
  const downloadPDF = () => {
    // This would be implemented with your PDF generation logic
    toast({
      title: "Downloading PDF",
      description: "Your resume PDF is being generated and downloaded.",
    })
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Semantic Resume Editor</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={saveResume} disabled={loading}>
            <Save className="mr-2 h-4 w-4" />
            {loading ? "Saving..." : "Save"}
          </Button>
          <Button onClick={downloadPDF}>
            <FileDown className="mr-2 h-4 w-4" />
            Download PDF
          </Button>
        </div>
      </div>

      <div className="h-[calc(100vh-150px)]">
        <ResizablePanels
          initialLeftWidth={45}
          minLeftWidth={30}
          maxLeftWidth={70}
          leftPanel={<PDFPreview sections={sections} />}
          rightPanel={
            <>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">Resume Content</h2>
                <Button variant="outline" size="sm" onClick={addSection}>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add Section
                </Button>
              </div>

              <DndProvider backend={HTML5Backend}>
                <div className="space-y-4">
                  {sections.map((section, index) => (
                    <ResumeSection
                      key={section.id}
                      section={section}
                      index={index}
                      moveSection={moveSection}
                      moveItem={moveItem}
                      moveBulletPoint={moveBulletPoint}
                      toggleSectionStatus={toggleSectionStatus}
                      toggleSectionCollapse={toggleSectionCollapse}
                      toggleItemStatus={toggleItemStatus}
                      toggleItemCollapse={toggleItemCollapse}
                      toggleBulletStatus={toggleBulletStatus}
                      updateSectionTitle={updateSectionTitle}
                      updateItem={updateItem}
                      updateBulletText={updateBulletText}
                      addItem={addItem}
                      addBulletPoint={addBulletPoint}
                    />
                  ))}
                </div>
              </DndProvider>
            </>
          }
        />
      </div>
    </div>
  )
}
