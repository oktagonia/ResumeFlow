"use client"

import type React from "react"

import { useResizable } from "@/hooks/use-resizable"
import { cn } from "@/lib/utils"

interface ResizablePanelsProps {
  leftPanel: React.ReactNode
  rightPanel: React.ReactNode
  initialLeftWidth?: number
  minLeftWidth?: number
  maxLeftWidth?: number
  className?: string
}

export function ResizablePanels({
  leftPanel,
  rightPanel,
  initialLeftWidth = 50,
  minLeftWidth = 30,
  maxLeftWidth = 70,
  className,
}: ResizablePanelsProps) {
  const { leftWidth, rightWidth, isResizing, startResizing } = useResizable({
    initialWidth: initialLeftWidth,
    minWidth: minLeftWidth,
    maxWidth: maxLeftWidth,
  })

  return (
    <div className={cn("flex w-full h-full", className)}>
      <div className="overflow-auto bg-white rounded-lg shadow-md p-4" style={{ width: `${leftWidth}%` }}>
        {leftPanel}
      </div>

      <div
        className={cn(
          "w-2 cursor-col-resize flex items-center justify-center bg-gray-100 hover:bg-gray-200 active:bg-gray-300",
          isResizing && "bg-gray-300",
        )}
        onMouseDown={startResizing}
      >
        <div className="w-1 h-8 bg-gray-400 rounded-full"></div>
      </div>

      <div className="overflow-auto bg-white rounded-lg shadow-md p-4" style={{ width: `${rightWidth}%` }}>
        {rightPanel}
      </div>
    </div>
  )
}
